O presente documento constitui uma s�ntese dos ficheiros DEUCP que encontrar� nesta pasta ZIP.

espd.XML: O ficheiro XML � um que o nosso servi�o DEUCP ou outros servi�os compat�veis DEUCP podem compreender. A vantagem de utilizar o eDEUCP como um ficheiro XML � que tanto os compradores como as empresas podem voltar a utiliz�-lo para outros procedimentos no futuro. Deve ser enviado juntamente com os documentos do concurso (da entidade adjudicante para as empresas) ou como parte integrante da proposta (da empresa para a entidade adjudicante).

espd.PDF: O ficheiro PDF � um ficheiro do eDEUCP apto � leitura humana . Tamb�m neste caso sugerimos que seja utilizado em paralelo com o formato XML com os documentos do concurso (da entidade adjudicante para as empresas) ou como parte integrante da proposta (da empresa para a entidade adjudicante) como documento de refer�ncia.

Se tem quest�es sobre os ficheiros n�o hesite em contacto connosco via correio eletr�nico para o seguinte endere�o: grow-espd@ec.europa.eu